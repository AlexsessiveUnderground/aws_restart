print("Hello, World")
python3 <lab-python-file-name>.py
